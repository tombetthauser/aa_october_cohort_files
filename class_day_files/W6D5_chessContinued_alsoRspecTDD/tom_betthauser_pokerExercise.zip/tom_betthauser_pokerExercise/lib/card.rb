require "Player"

class Card

  attr_reader :value, :suit, :face_up, :holder

  def initialize(value, suit, holder = nil)
    @value = value
    @suit = suit
    @face_up = false
    @holder = holder
  end

  def flip_card
    @face_up = @face_up ? false : true
  end

  def add_holder(player)
    if @holder.nil? && player.is_a?(Player)
      @holder = player
      @holder.hand << self
      true
    else
      false
    end
  end

end