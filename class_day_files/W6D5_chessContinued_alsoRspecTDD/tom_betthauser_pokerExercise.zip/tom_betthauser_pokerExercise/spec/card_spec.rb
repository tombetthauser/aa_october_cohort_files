require "card.rb"

describe Card do
  subject(:card) { Card.new(:king, :clubs) }

  describe "#initialize" do 
    it "it will be accept a readable @value variable" do
      expect(card.value).to eq(:king)
    end

    it "it will be accept a readable @suit variable" do
      expect(card.suit).to eq(:clubs)
    end
    
    it "will initialize all cards with a readable @face_up variable of false" do
      expect(card.face_up).to eq(false)
    end

    it "will initialize with readable @holder variable as nil" do
      expect(card.holder).to eq(nil)
    end
  end

  describe "#flip_card" do
    it "will flip a card from face up to face down" do
      card.flip_card
      expect(card.face_up).to eq(true)
    end
    
    it "will flip a card back to face up twice" do
      2.times { card.flip_card }
      expect(card.face_up).to eq(false)
    end
    
    it "will flip a card back to face up a large number of times" do
      212314.times { card.flip_card }
      expect(card.face_up).to eq(false)
    end    
  end

  describe "#add_holder" do 
    let(:player) { double("player", :name => "Tommy", :hand => []) }
    let(:player2) { double("player", :name => "Joey", :hand => []) }
    
    it "will accept an instance of Player and update @holder value with it" do
      card.add_holder(player)
      expect(card.holder.name).to eq("Tommy")
    end
    
    it "will add card instance to players hand" do
      card.add_holder(player)
      expect(player.hand).to eq([card])
    end
    
    it "will return false and do nothing if holder already exists" do
      card.add_holder(player2)
      card.add_holder(player)
      expect(card.holder.name).to eq("Joey")
    end
    
    it "will return false and do nothing if input is not Player instance" do
      card.add_holder("Elliot")
      expect(card.holder).to_not eq("Elliot")
    end
  end

end