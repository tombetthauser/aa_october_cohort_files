require "array.rb"

describe Array do

  describe "#uniq" do

    it "removes duplicates from an array" do
      expect([1,2,3,3].uniq).to eq([1,2,3])
    end

    it "maintains original order of array" do
      expect([1,2,1].uniq).to eq([1,2])
    end

    it "does not modify original array" do
      subject(arr = [1,2,3])
      expect(arr.uniq).to_not eq(arr)
    end

  end

end

