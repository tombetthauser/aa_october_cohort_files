require_relative 'Piece.rb'

class Nullpiece < Piece


end

null = Nullpiece.new

p null