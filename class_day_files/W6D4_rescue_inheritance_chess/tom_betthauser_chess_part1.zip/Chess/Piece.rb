
class Piece

end
piece = Piece.new
p piece