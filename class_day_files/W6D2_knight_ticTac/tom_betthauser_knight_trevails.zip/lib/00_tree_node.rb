require "byebug"

class PolyTreeNode
    attr_reader :parent, :children, :value

    def initialize(value)
        @value = value
        @parent = nil
        @children = []
    end

    def parent=(input)
        @parent.children.delete(self) unless @parent.nil?

        if input.nil? 
            @parent = nil
        else
            @parent = input
            @parent.children << self
        end

    end

    def add_child(child_node)
      child_node.parent = self
    end

    def remove_child(child_node)
        raise "node is not a child" if child_node.parent.nil?
        child_node.parent = nil
    end

    def dfs(target_value)
        return self if self.value == target_value

        self.children.each do |child|
          dfs_recur = child.dfs(target_value)
          return dfs_recur unless dfs_recur.nil?
        end

        nil
    end

    def bfs(target_value)
        queue = [self]

        until queue.empty?
            return queue.first if queue.first.value == target_value
            queue += queue.first.children
            queue.shift
        end

        nil
    end

    def inspect
        @value
    end

end