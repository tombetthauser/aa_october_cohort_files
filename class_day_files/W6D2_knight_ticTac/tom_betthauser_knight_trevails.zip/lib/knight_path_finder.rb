require_relative "00_tree_node.rb"

class KnightPathFinder
    attr_accessor :root_node, :considered_positions

    def self.valid_moves(pos)
        pos.all? { |coor| coor >= 0 && coor < 8 }
    end
    
    def initialize(starting_position)
        @root_node = PolyTreeNode.new(starting_position)
        @considered_positions = [starting_position]
    end
    
    def new_move_positions(pos)
        hypo_moves = [[2,1],[2,-1],[1,2],[1,-2],[-1,2],[-1,-2],[-2,1],[-2,-1]]
        hypo_moves.map! { |move| [(move[0] + pos[0]), (move[1] + pos[1])] }
        valid_moves = hypo_moves.select do |move| 
            KnightPathFinder.valid_moves(move) && !@considered_positions.include?(move) 
        end
        @considered_positions += valid_moves
        valid_moves
    end

    def build_move_tree
        queue = [@root_node]

        until queue.empty?
            first_inst = queue.shift
            new_move_positions(first_inst.value).each do |new_move|
                new_child = PolyTreeNode.new(new_move)
                first_inst.add_child(new_child)
                queue << new_child
            end
        end
    end

    def find_path(end_pos)
        end_polynode = @root_node.bfs(end_pos)
        trace_path_back(end_polynode)
    end

    def trace_path_back(end_polynode)
        nodes_arr = [end_polynode]
        until nodes_arr.first == @root_node
            parent = nodes_arr.first.parent
            nodes_arr.unshift(parent)
        end
        
        nodes_arr.map { |node| node.value }
    end
    

end

inst = KnightPathFinder.new([0, 0])
inst.build_move_tree
p inst.find_path([7,6])
p inst.find_path([6, 2]) 