class Array
  # Write a new `Array#merge_sort` method; it should not modify the
  # array it is called on, but create a new sorted array.
  def merge_sort(&prc)
  end

  private
  def self.merge(left, right, &prc)
  end

end

class Array
  # Write an array method that returns `true` if two elements of the array sum
  # to 0 and `false` otherwise
  def two_sum
  end
end

# Write a method that finds the first `n` Fibonacci numbers recursively.
def fibs_rec(count)
end

class String
  # Write a method that returns `true` if all characters in the string
  # are unique and `false` if they are not
  def all_unique_chars?
  end
end

# Write a method that returns the largest prime factor of a number
def largest_prime_factor(num)
end

# You are not required to implement this; it's here as a suggestion :-)
def prime?(num)
end

class Array
  # Write a method that calls a passed block for each element of the array
  def my_each(&prc)
  end
end

class Array
  # Write an array method that returns `true` if all elements in an array
  # return `true` for the passed block and `false` otherwise 
  def my_all?(&prc)
  end
end

