require_relative "00_tree_node.rb"

class KnightPathFinder

    def self.valid_moves(pos)
        pos.all? { |coor| coor >= 0 && coor < 8 }
    end
    
    def initialize(starting_position)
        @positions = PolyTreeNode.new(starting_position)
        @considered_positions = [starting_position]
    end
    
    def new_move_positions(pos)
        hypo_moves = [[2,1],[2,-1],[1,2],[1,-2],[-1,2],[-1,-2],[-2,1],[-2,-1]]
        hypo_moves.map! { |move| [(move[0] + pos[0]), (move[1] + pos[1])] }
        valid_moves = hypo_moves.select do |move| 
            KnightPathFinder.valid_moves(move) && !@considered_positions.include?(move) 
        end
        @considered_positions += valid_moves
        valid_moves
    end

    def build_move_tree
        # 
    end

end

# inst = KnightPathFinder.new([0, 0])
# p inst.new_move_positions([0, 0])
# p inst.new_move_positions([3, 3])