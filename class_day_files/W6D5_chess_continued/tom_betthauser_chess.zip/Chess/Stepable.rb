
module Stepable

    def moves
        #will finish
    end

    private

    def move_diffs
        
    end

end