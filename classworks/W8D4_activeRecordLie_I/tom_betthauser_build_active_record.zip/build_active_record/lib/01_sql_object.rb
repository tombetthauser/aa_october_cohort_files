require_relative 'db_connection'
require 'active_support/inflector'
# NB: the attr_accessor we wrote in phase 0 is NOT used in the rest
# of this project. It was only a warm up.

class SQLObject
  def self.columns
   @data ||= DBConnection.instance.execute2(<<-SQL)
      SELECT
        *
      FROM
        #{self.table_name}
    SQL
    .first
    .map(&:to_sym)
  end

  def self.finalize!
    cols = self.columns
    cols.each do |col|
      define_method(col) do
      #  self.instance_variable_get("@#{col}")
       self.attributes[col]
      end

      define_method("#{col}=") do |val|
          # self.instance_variable_set("@#{col}", val)
         self.attributes[col] = val
        
      end
    end
  end

  def self.table_name=(table_name)
    
  end

  def self.table_name
    self.name.downcase + "s"
  end

  def self.all
    data = DBConnection.execute(<<-SQL)
      SELECT
        *
      FROM
        #{self.table_name}
    SQL

    self.parse_all(data)
  end

  def self.parse_all(results)
    results.map do |result|
      self.new(result)
    end
  end

  def self.find(id)
    self.all[id-1]
  end

  def initialize(params = {})
    cols = self.class.columns

    params.each do |k,v|
    
      raise "unknown attribute '#{k}'" unless cols.include?(k.to_sym)
      self.send("#{k}=", v)
    end
  end

  def attributes
    @attributes ||= {}
   
  end

  def attribute_values
    self.attributes.values
  end

  def insert
    col_names = self.class.columns
    q_marks = ["?"] * (col_names.length - 1) 

    DBConnection.execute(<<-SQL, *self.attribute_values)
    INSERT INTO
      #{self.class.table_name} (#{col_names[1..-1].join(", ")})
    VALUES
      (#{q_marks.join(", ")})
    SQL
    
    self.id = DBConnection.last_insert_row_id
  end

  def update
    col_names = self.class.columns
    col_names = col_names.map { |col| col.to_s + " = ?" }
    
    DBConnection.execute(<<-SQL, *self.attribute_values[1..-1], self.attribute_values.first)
      UPDATE
        #{self.class.table_name}
      SET
        #{col_names[1..-1].join(", ")}
      WHERE
        id = ?
    SQL

    self.id = DBConnection.last_insert_row_id
  end

  def save
    self.id.nil? ? self.insert : self.update
  end
end
