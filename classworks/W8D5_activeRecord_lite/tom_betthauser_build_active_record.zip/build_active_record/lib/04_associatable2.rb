require_relative '03_associatable'

# Phase IV
module Associatable
  # Remember to go back to 04_associatable to write ::assoc_options

  def has_one_through(name, through_name, source_name)
    # ...
 
    define_method(name) do
      p name
      p through_name
      p source_name
      p through_options = self.class.assoc_options[through_name]
      p source_options = through_options.model_class.assoc_options[source_name]
      # DBConnection.execute(<<-SQL)
      #   SELECT 
      #   houses.*
      #   FROM 
      #     cats
      #   JOIN 
      #     humans ON cats.owner_id = humans.id
      #   JOIN
      #     houses ON humans.house_id = houses.id
      # SQL
        DBConnection.execute(<<-SQL)
          SELECT
            houses.*
          FROM
            humans
          JOIN
            houses ON humans.house_id = houses.id
        SQL
      .map { |datum| House.new(datum) }.first
    end
  end
end


# class Cat
#   has_one :home, 
#     through: :human, source: :house

# end