require_relative '02_searchable'
require 'active_support/inflector'

# Phase IIIa
class AssocOptions
  attr_accessor(
    :foreign_key,
    :class_name,
    :primary_key
  )

  def model_class
    self.class_name.to_s.constantize
  end

  def table_name
    self.model_class.name.downcase + "s"
  end
end

class BelongsToOptions < AssocOptions
  def initialize(name, options = {})
  
    @foreign_key = options[:foreign_key] || "#{name}_id".to_sym
    @class_name = options[:class_name] || name.to_s.capitalize
    @primary_key = options[:primary_key] || :id
  end
end

class HasManyOptions < AssocOptions
  def initialize(name, self_class_name, options = {})
    @foreign_key = options[:foreign_key] || "#{self_class_name.downcase}_id".to_sym
    @class_name = options[:class_name] || name.to_s.singularize.capitalize
    @primary_key = options[:primary_key] || :id
  end
end

module Associatable
  # Phase IIIb
  def belongs_to(name, options = {})
   option = BelongsToOptions.new(name, options)
   self.assoc_options[name] = option
    define_method(name) do
      for_key = option.send(:foreign_key)
      target = option.model_class
      target.where(:id => self.send(for_key)).first
    end
  end

  def has_many(name, options = {})
   
      something = self.name
      option = HasManyOptions.new(name, something, options)
     
      define_method(name) do
        prim_key = option.send(:primary_key)
        target = option.model_class
        target.where(option.send(:foreign_key) => self.send(prim_key))
      end
  end

  def assoc_options
    # Wait to implement this in Phase IVa. Modify `belongs_to`, too.
    @assoc ||= {}
  end
end

class SQLObject
  extend Associatable
end
