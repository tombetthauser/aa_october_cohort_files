require 'test_helper'

class SeedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
